# Price_Prediction_Model_using_Linear_Regression
Based on the Linear Regression Algorithm, this model helps to predict the price of houses having different criteria.
![Screenshot 2022-02-24 132513](https://user-images.githubusercontent.com/70774888/155896121-fd104bc8-4f0d-4ebb-b69e-844aec466241.png)
![Screenshot 2022-02-24 133320](https://user-images.githubusercontent.com/70774888/155896125-9a1f8a47-3d60-44f2-a580-c3ad8a11c0f3.png)
